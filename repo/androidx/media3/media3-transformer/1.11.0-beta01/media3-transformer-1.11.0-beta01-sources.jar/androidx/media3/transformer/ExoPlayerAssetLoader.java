/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.transformer;

import static androidx.media3.common.util.Util.percentInt;
import static androidx.media3.transformer.ExportException.ERROR_CODE_FAILED_RUNTIME_CHECK;
import static androidx.media3.transformer.ExportException.ERROR_CODE_UNSPECIFIED;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_AVAILABLE;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_NOT_STARTED;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_UNAVAILABLE;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_WAITING_FOR_AVAILABILITY;
import static androidx.media3.transformer.TransformerUtil.isImage;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.abs;
import static java.lang.Math.min;

import android.content.Context;
import android.media.metrics.LogSessionId;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline;
import androidx.media3.common.Tracks;
import androidx.media3.common.audio.SpeedProvider;
import androidx.media3.common.util.Clock;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.ExoTimeoutException;
import androidx.media3.exoplayer.LoadControl;
import androidx.media3.exoplayer.Renderer;
import androidx.media3.exoplayer.RenderersFactory;
import androidx.media3.exoplayer.audio.AudioRendererEventListener;
import androidx.media3.exoplayer.metadata.MetadataOutput;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.text.TextOutput;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.exoplayer.trackselection.TrackSelector;
import androidx.media3.exoplayer.video.VideoRendererEventListener;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.amr.AmrExtractor;
import androidx.media3.extractor.mp4.Mp4Extractor;
import androidx.media3.extractor.ts.AdtsExtractor;
import com.google.common.base.Supplier;
import com.google.common.collect.ImmutableMap;
import java.util.ArrayList;

/** An {@link AssetLoader} implementation that uses an {@link ExoPlayer} to load samples. */
@UnstableApi
public final class ExoPlayerAssetLoader implements AssetLoader {

  /** An {@link AssetLoader.Factory} for {@link ExoPlayerAssetLoader} instances. */
  public static final class Factory implements AssetLoader.Factory {

    private final Context context;
    private final Codec.DecoderFactory decoderFactory;
    private final Clock clock;
    @Nullable private final MediaSource.Factory mediaSourceFactory;
    private final TrackSelector.Factory trackSelectorFactory;
    @Nullable private final LogSessionId logSessionId;
    private final Supplier<LoadControl> loadControlSupplier;

    /**
     * Creates an instance using a {@link DefaultMediaSourceFactory}.
     *
     * @param context The {@link Context}.
     * @param decoderFactory The {@link Codec.DecoderFactory} to use to decode the samples (if
     *     necessary).
     * @param clock The {@link Clock} to use. It should always be {@link Clock#DEFAULT}, except for
     *     testing.
     */
    public Factory(Context context, Codec.DecoderFactory decoderFactory, Clock clock) {
      // TODO: b/381519379 - Deprecate this constructor and replace with a builder.
      this(
          context,
          decoderFactory,
          clock,
          /* mediaSourceFactory= */ null,
          /* trackSelectorFactory= */ null,
          /* logSessionId= */ null,
          /* loadControl= */ null);
    }

    /**
     * Creates an instance using a {@link DefaultMediaSourceFactory}.
     *
     * @param context The {@link Context}.
     * @param decoderFactory The {@link Codec.DecoderFactory} to use to decode the samples (if
     *     necessary).
     * @param clock The {@link Clock} to use. It should always be {@link Clock#DEFAULT}, except for
     *     testing.
     * @param loadControl The {@link LoadControl} to use in the underlying {@link ExoPlayer}.
     */
    public Factory(
        Context context,
        Codec.DecoderFactory decoderFactory,
        Clock clock,
        LoadControl loadControl) {
      // TODO: b/381519379 - Deprecate this constructor and replace with a builder.
      this(
          context,
          decoderFactory,
          clock,
          /* mediaSourceFactory= */ null,
          /* trackSelectorFactory= */ null,
          /* logSessionId= */ null,
          loadControl);
    }

    /**
     * Creates an instance.
     *
     * @param context The {@link Context}.
     * @param decoderFactory The {@link Codec.DecoderFactory} to use to decode the samples (if
     *     necessary).
     * @param clock The {@link Clock} to use. It should always be {@link Clock#DEFAULT}, except for
     *     testing.
     * @param mediaSourceFactory The {@link MediaSource.Factory} to use to retrieve the samples to
     *     transform.
     */
    public Factory(
        Context context,
        Codec.DecoderFactory decoderFactory,
        Clock clock,
        MediaSource.Factory mediaSourceFactory) {
      // TODO: b/381519379 - Deprecate this constructor and replace with a builder.
      this(
          context,
          decoderFactory,
          clock,
          mediaSourceFactory,
          /* trackSelectorFactory= */ null,
          /* logSessionId= */ null,
          /* loadControl= */ null);
    }

    /**
     * Creates an instance.
     *
     * @param context The {@link Context}.
     * @param decoderFactory The {@link Codec.DecoderFactory} to use to decode the samples (if
     *     necessary).
     * @param clock The {@link Clock} to use. It should always be {@link Clock#DEFAULT}, except for
     *     testing.
     * @param mediaSourceFactory The {@link MediaSource.Factory} to use to retrieve the samples to
     *     transform.
     * @param trackSelectorFactory The {@link TrackSelector.Factory} to use when selecting the track
     *     to transform.
     * @param logSessionId The optional {@link LogSessionId} of the {@link
     *     android.media.metrics.EditingSession}.
     * @param loadControl The {@link LoadControl} to use in the underlying {@link ExoPlayer}.
     */
    public Factory(
        Context context,
        Codec.DecoderFactory decoderFactory,
        Clock clock,
        @Nullable MediaSource.Factory mediaSourceFactory,
        @Nullable TrackSelector.Factory trackSelectorFactory,
        @Nullable LogSessionId logSessionId,
        @Nullable LoadControl loadControl) {
      // TODO: b/381519379 - Deprecate this constructor and replace with a builder.
      this.context = context;
      this.decoderFactory = decoderFactory;
      this.clock = clock;
      this.mediaSourceFactory = mediaSourceFactory;

      if (trackSelectorFactory == null) {
        DefaultTrackSelector.Parameters defaultTrackSelectorParameters =
            new DefaultTrackSelector.Parameters.Builder()
                .setForceHighestSupportedBitrate(true)
                .setConstrainAudioChannelCountToDeviceCapabilities(false)
                .build();
        trackSelectorFactory =
            ctx -> {
              DefaultTrackSelector trackSelector = new DefaultTrackSelector(ctx);
              trackSelector.setParameters(defaultTrackSelectorParameters);
              return trackSelector;
            };
      }
      this.trackSelectorFactory = trackSelectorFactory;
      this.logSessionId = logSessionId;
      // We need a new LoadControl instance for every asset loader because these might run on
      // different threads. Each TransformerInternal instance creates a new processing thread.
      if (loadControl == null) {
        this.loadControlSupplier = DefaultLoadControl::new;
      } else {
        this.loadControlSupplier = () -> loadControl;
      }
    }

    @Override
    public AssetLoader createAssetLoader(
        EditedMediaItem editedMediaItem,
        Looper looper,
        Listener listener,
        CompositionSettings compositionSettings) {
      // TODO: b/512407542 - Avoid creating a new factory for each EditedMediaItem and assert that
      // SEF is not used more than once within a Composition.
      return new ExoPlayerAssetLoader(
          context,
          editedMediaItem,
          mediaSourceFactory != null
              ? mediaSourceFactory
              : createMediaSourceFactory(context, editedMediaItem.flattenForSlowMotion),
          decoderFactory,
          compositionSettings.hdrMode,
          looper,
          listener,
          clock,
          trackSelectorFactory,
          logSessionId,
          loadControlSupplier.get());
    }

    private static MediaSource.Factory createMediaSourceFactory(
        Context context, boolean shouldEnableSef) {
      DefaultExtractorsFactory defaultExtractorsFactory =
          new DefaultExtractorsFactory()
              .setAdtsExtractorFlags(AdtsExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING)
              .setAmrExtractorFlags(AmrExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING);
      if (shouldEnableSef) {
        defaultExtractorsFactory.setMp4ExtractorFlags(Mp4Extractor.FLAG_READ_SEF_DATA);
      }
      return new DefaultMediaSourceFactory(context, defaultExtractorsFactory)
          .setEnableClippingInMediaPeriod(true);
    }
  }

  private static final String TAG = "ExoPlayerAssetLoader";

  /**
   * Maximum allowed {@link EditedMediaItem} duration update in microseconds.
   *
   * <p>20ms should cover the main known valid case of a duration update, which is an Mp3 file with
   * a trailing ID3v1 tag. An ID3v1 tag is exactly 128 bytes, which at most can represent 16ms of
   * audio at a constant bitrate of 64 kb/s.
   */
  private static final int MAX_ALLOWED_DURATION_DIFF_US = 20_000;

  private final Context context;
  private final EditedMediaItem editedMediaItem;
  private final CapturingDecoderFactory decoderFactory;
  private final ExoPlayer player;
  private final MediaSource.Factory mediaSourceFactory;

  private @Transformer.ProgressState int progressState;
  private long durationUs;

  private ExoPlayerAssetLoader(
      Context context,
      EditedMediaItem editedMediaItem,
      MediaSource.Factory mediaSourceFactory,
      Codec.DecoderFactory decoderFactory,
      @Composition.HdrMode int hdrMode,
      Looper looper,
      Listener listener,
      Clock clock,
      TrackSelector.Factory trackSelectorFactory,
      @Nullable LogSessionId logSessionId,
      LoadControl loadControl) {
    this.context = context;
    this.editedMediaItem = editedMediaItem;
    this.decoderFactory = new CapturingDecoderFactory(decoderFactory);
    this.mediaSourceFactory = mediaSourceFactory;

    TrackSelector trackSelector = trackSelectorFactory.createTrackSelector(context);
    ExoPlayer.Builder playerBuilder =
        new ExoPlayer.Builder(
                context,
                new RenderersFactoryImpl(
                    editedMediaItem, this.decoderFactory, hdrMode, listener, logSessionId))
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setLooper(looper)
            .setStuckBufferingDetectionTimeoutMs(Integer.MAX_VALUE)
            .setStuckPlayingDetectionTimeoutMs(Integer.MAX_VALUE)
            .setStuckPlayingNotEndingTimeoutMs(Integer.MAX_VALUE)
            .setUsePlatformDiagnostics(false);
    if (decoderFactory instanceof DefaultDecoderFactory) {
      playerBuilder.experimentalSetDynamicSchedulingEnabled(
          ((DefaultDecoderFactory) decoderFactory).isDynamicSchedulingEnabled());
    }
    if (clock != Clock.DEFAULT) {
      // Transformer.Builder#setClock is also @VisibleForTesting, so if we're using a non-default
      // clock we must be in a test context.
      @SuppressWarnings("VisibleForTests")
      ExoPlayer.Builder unusedForAnnotation = playerBuilder.setClock(clock);
    }
    player = playerBuilder.build();
    player.addListener(new PlayerListener(listener));

    progressState = PROGRESS_STATE_NOT_STARTED;
    durationUs = C.TIME_UNSET;
  }

  @Override
  public void start() {
    player.setMediaSource(createMediaSourceForEditedMediaItem(mediaSourceFactory, editedMediaItem));
    player.prepare();
    progressState = PROGRESS_STATE_WAITING_FOR_AVAILABILITY;
  }

  @Override
  public @Transformer.ProgressState int getProgress(ProgressHolder progressHolder) {
    if (progressState == PROGRESS_STATE_AVAILABLE) {
      long durationMs = durationUs / 1_000;
      // The player position can become greater than the duration. This happens if the player is
      // using a StandaloneMediaClock because the renderers have ended.
      long positionMs = min(player.getCurrentPosition(), durationMs);
      progressHolder.progress = percentInt(positionMs, durationMs);
    }
    return progressState;
  }

  @Override
  public ImmutableMap<Integer, String> getDecoderNames() {
    ImmutableMap.Builder<Integer, String> decoderNamesByTrackType = new ImmutableMap.Builder<>();
    @Nullable String audioDecoderName = decoderFactory.getAudioDecoderName();
    if (audioDecoderName != null) {
      decoderNamesByTrackType.put(C.TRACK_TYPE_AUDIO, audioDecoderName);
    }
    @Nullable String videoDecoderName = decoderFactory.getVideoDecoderName();
    if (videoDecoderName != null) {
      decoderNamesByTrackType.put(C.TRACK_TYPE_VIDEO, videoDecoderName);
    }
    return decoderNamesByTrackType.buildOrThrow();
  }

  @Override
  public void release() {
    player.release();
    progressState = PROGRESS_STATE_NOT_STARTED;
  }

  /**
   * Returns a {@link MediaSource} representing the provided {@link EditedMediaItem}.
   *
   * <p>This method creates the {@link MediaSource} using {@code factory} and optionally wraps the
   * new source in a {@link SpeedChangingMediaSource}.
   */
  private static MediaSource createMediaSourceForEditedMediaItem(
      MediaSource.Factory factory, EditedMediaItem editedMediaItem) {
    MediaSource mediaSource = factory.createMediaSource(editedMediaItem.mediaItem);
    if (editedMediaItem.speedProvider != SpeedProvider.DEFAULT) {
      mediaSource =
          new SpeedChangingMediaSource(
              mediaSource,
              editedMediaItem.speedProvider,
              editedMediaItem.mediaItem.clippingConfiguration);
    }
    return mediaSource;
  }

  private static final class RenderersFactoryImpl implements RenderersFactory {

    private final TransformerMediaClock mediaClock;
    private final EditedMediaItem editedMediaItem;
    private final Codec.DecoderFactory decoderFactory;
    private final @Composition.HdrMode int hdrMode;
    private final Listener assetLoaderListener;
    @Nullable private final LogSessionId logSessionId;

    public RenderersFactoryImpl(
        EditedMediaItem editedMediaItem,
        Codec.DecoderFactory decoderFactory,
        @Composition.HdrMode int hdrMode,
        Listener assetLoaderListener,
        @Nullable LogSessionId logSessionId) {
      this.editedMediaItem = editedMediaItem;
      this.decoderFactory = decoderFactory;
      this.hdrMode = hdrMode;
      this.assetLoaderListener = assetLoaderListener;
      this.logSessionId = logSessionId;
      mediaClock = new TransformerMediaClock();
    }

    @Override
    public Renderer[] createRenderers(
        Handler eventHandler,
        VideoRendererEventListener videoRendererEventListener,
        AudioRendererEventListener audioRendererEventListener,
        TextOutput textRendererOutput,
        MetadataOutput metadataRendererOutput) {
      ArrayList<Renderer> renderers = new ArrayList<>();
      if (!editedMediaItem.removeAudio) {
        renderers.add(
            new ExoAssetLoaderAudioRenderer(
                decoderFactory, mediaClock, assetLoaderListener, logSessionId));
      }
      if (!editedMediaItem.removeVideo) {
        renderers.add(
            new ExoAssetLoaderVideoRenderer(
                editedMediaItem.flattenForSlowMotion,
                decoderFactory,
                hdrMode,
                mediaClock,
                assetLoaderListener,
                logSessionId,
                editedMediaItem.frameRate));
      }
      return renderers.toArray(new Renderer[0]);
    }
  }

  private final class PlayerListener implements Player.Listener {

    private final Listener assetLoaderListener;

    public PlayerListener(Listener assetLoaderListener) {
      this.assetLoaderListener = assetLoaderListener;
    }

    @Override
    public void onTimelineChanged(Timeline timeline, int reason) {
      try {
        Timeline.Window window = new Timeline.Window();
        timeline.getWindow(/* windowIndex= */ 0, window);
        if (!window.isPlaceholder) {
          if (progressState == PROGRESS_STATE_WAITING_FOR_AVAILABILITY) {
            durationUs = window.durationUs;
            // Make progress permanently unavailable if the duration is unknown, so that it doesn't
            // jump to a high value at the end of the export if the duration is set once the media
            // is entirely loaded.
            progressState =
                durationUs <= 0 || durationUs == C.TIME_UNSET
                    ? PROGRESS_STATE_UNAVAILABLE
                    : PROGRESS_STATE_AVAILABLE;
            assetLoaderListener.onDurationUs(window.durationUs);
          } else if (durationUs != C.TIME_UNSET) {
            // ExoPlayer will do a best effort duration estimation for media that does not expose
            // an explicit duration in its container. On some cases, like with Mp3 files with
            // trailing ID3v1 tags, ExoPlayer will update the Timeline's duration with the real
            // duration once the file has been read completely. We should ignore these updates and
            // let Transformer pad the stream with silence/blank frames. However, for duration
            // updates that exceed the threshold, we should crash.
            checkState(
                abs(durationUs - window.durationUs) <= MAX_ALLOWED_DURATION_DIFF_US,
                "Unexpected duration change: old=%s, new=%s",
                durationUs,
                window.durationUs);
          }
        }
      } catch (RuntimeException e) {
        assetLoaderListener.onError(
            ExportException.createForAssetLoader(e, ERROR_CODE_UNSPECIFIED));
      }
    }

    @Override
    public void onTracksChanged(Tracks tracks) {
      try {
        int trackCount = 0;
        if (tracks.isTypeSelected(C.TRACK_TYPE_AUDIO)) {
          trackCount++;
        }
        if (tracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) {
          trackCount++;
        }

        maybeWarnUnsupportedTrackTypes(tracks);
        if (trackCount > 0) {
          assetLoaderListener.onTrackCount(trackCount);
          // Start the renderers after having registered all the tracks to make sure the AssetLoader
          // listener callbacks are called in the right order.
          player.play();
        } else {
          String errorMessage = "The asset loader has no audio or video track to output.";
          if (isImage(context, editedMediaItem.mediaItem)) {
            errorMessage += " Try setting an image duration on input image MediaItems.";
          }
          assetLoaderListener.onError(
              ExportException.createForAssetLoader(
                  new IllegalStateException(errorMessage), ERROR_CODE_FAILED_RUNTIME_CHECK));
        }
      } catch (RuntimeException e) {
        assetLoaderListener.onError(
            ExportException.createForAssetLoader(e, ERROR_CODE_UNSPECIFIED));
      }
    }

    @Override
    public void onPlayerError(PlaybackException error) {
      Throwable cause = error.getCause();
      if ((cause instanceof ExoTimeoutException)
          && ((ExoTimeoutException) cause).timeoutOperation
              == ExoTimeoutException.TIMEOUT_OPERATION_RELEASE) {
        // Don't throw if releasing the player timed out to prevent the export to fail.
        Log.e(TAG, "Releasing the player timed out.", error);
        return;
      }
      @ExportException.ErrorCode
      int errorCode =
          checkNotNull(
              ExportException.NAME_TO_ERROR_CODE.getOrDefault(
                  error.getErrorCodeName(), ERROR_CODE_UNSPECIFIED));
      assetLoaderListener.onError(ExportException.createForAssetLoader(error, errorCode));
    }
  }

  private static void maybeWarnUnsupportedTrackTypes(Tracks tracks) {
    for (int i = 0; i < tracks.getGroups().size(); i++) {
      @C.TrackType int trackType = tracks.getGroups().get(i).getType();
      if (trackType == C.TRACK_TYPE_AUDIO || trackType == C.TRACK_TYPE_VIDEO) {
        continue;
      }
      Log.w(TAG, "Unsupported track type: " + trackType);
    }
  }
}
