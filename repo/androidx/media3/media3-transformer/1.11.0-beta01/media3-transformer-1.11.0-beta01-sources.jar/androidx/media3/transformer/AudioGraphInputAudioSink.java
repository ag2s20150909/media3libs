/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static androidx.media3.common.audio.AudioProcessor.EMPTY_BUFFER;
import static androidx.media3.common.util.Util.getPcmFrameSize;
import static androidx.media3.common.util.Util.isEncodingLinearPcm;
import static androidx.media3.common.util.Util.sampleCountToDurationUs;
import static androidx.media3.effect.DebugTraceUtil.COMPONENT_AUDIO_GRAPH_INPUT_AUDIO_SINK;
import static androidx.media3.effect.DebugTraceUtil.EVENT_DISCONTINUITY;
import static androidx.media3.effect.DebugTraceUtil.EVENT_FLUSH;
import static androidx.media3.effect.DebugTraceUtil.EVENT_INPUT_ENDED;
import static androidx.media3.effect.DebugTraceUtil.EVENT_INPUT_FORMAT;
import static androidx.media3.effect.DebugTraceUtil.EVENT_RESET;
import static androidx.media3.transformer.TransformerUtil.getEditedMediaItem;
import static androidx.media3.transformer.TransformerUtil.getOffsetToCompositionTimeUs;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import android.media.AudioTrack;
import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.AuxEffectInfo;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Timeline;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.effect.DebugTraceUtil;
import androidx.media3.exoplayer.Renderer;
import androidx.media3.exoplayer.audio.AudioSink;
import androidx.media3.exoplayer.source.MediaSource.MediaPeriodId;
import java.nio.ByteBuffer;
import java.util.Objects;
import org.checkerframework.checker.nullness.qual.EnsuresNonNullIf;

/**
 * An {@link AudioSink} implementation that feeds an {@link AudioGraphInput}.
 *
 * <p>Should be used by {@link PlaybackAudioGraphWrapper}.
 */
/* package */ final class AudioGraphInputAudioSink implements AudioSink {

  /**
   * Controller for {@link AudioGraphInputAudioSink}.
   *
   * <p>All methods will be called on the playback thread of the ExoPlayer instance writing to this
   * sink.
   */
  public interface Controller {

    /**
     * Returns the {@link AudioGraphInput} instance associated with this {@linkplain
     * AudioGraphInputAudioSink sink}.
     *
     * <p>If AudioGraphInput is not available, callers should re-try again later.
     *
     * <p>Data {@linkplain #handleBuffer written} to the sink will be {@linkplain
     * AudioGraphInput#queueInputBuffer() queued} to the {@link AudioGraphInput}.
     *
     * <p>Call {@link #onAudioGraphInputReleased()} once the input has been {@linkplain
     * AudioGraphInput#release() released}.
     *
     * @param editedMediaItem The first {@link EditedMediaItem} queued to the {@link
     *     AudioGraphInput}.
     * @param format The {@link Format} used to {@linkplain AudioGraphInputAudioSink#configure
     *     configure} the {@linkplain AudioGraphInputAudioSink sink}.
     * @return The {@link AudioGraphInput}, or {@code null} if the input is not available yet.
     * @throws ExportException If there is a problem initializing the {@linkplain AudioGraphInput
     *     input}.
     */
    @Nullable
    AudioGraphInput getAudioGraphInput(EditedMediaItem editedMediaItem, Format format)
        throws ExportException;

    /**
     * Notifies that this {@link AudioGraphInputAudioSink}'s {@link AudioGraphInput} has been
     * {@linkplain AudioGraphInput#release() released} and is no longer in use.
     */
    void onAudioGraphInputReleased();

    /**
     * Returns the position (in microseconds) that should be {@linkplain
     * AudioSink#getCurrentPositionUs returned} by this sink.
     *
     * @param sourceEnded Specify {@code true} if no more input buffers will be provided.
     * @return The playback position relative to the start of playback, in microseconds.
     */
    long getCurrentPositionUs(boolean sourceEnded);

    /**
     * Returns whether global audio pipeline state allows this sink to signal {@link #isEnded()}.
     *
     * <p>{@link PlaybackAudioGraphWrapper} requires calls to {@link Renderer#render} to push output
     * from the {@link AudioGraph} into the final audio sink. Therefore, one {@link
     * AudioGraphInputAudioSink} needs to stay alive until all buffers have been queued into the
     * final sink, even if that {@link AudioGraphInputAudioSink} instance has finished queuing data
     * onto its {@link AudioGraphInput}.
     */
    boolean shouldEnd();
  }

  private final Controller controller;

  @Nullable private AudioGraphInput outputGraphInput;
  @Nullable private Format currentInputFormat;
  private boolean inputStreamEnded;
  private boolean signalledEndOfStream;
  @Nullable private EditedMediaItem currentEditedMediaItem;
  private long offsetToCompositionTimeUs;
  private long inputPositionUs;
  private long outputStreamOffsetUs;
  private long offsetToEditedMediaItemStartUs;
  private boolean isConfigurationPending;
  private boolean isFlushPending;

  public AudioGraphInputAudioSink(Controller controller) {
    this.controller = controller;
  }

  // AudioSink methods

  @Override
  public void configure(AudioSinkConfig audioSinkConfig) {
    checkArgument(supportsFormat(audioSinkConfig.format));
    // TODO: b/303029969 - Evaluate throwing vs ignoring for null outputChannels.
    checkArgument(audioSinkConfig.outputChannelMapping == null);

    DebugTraceUtil.logEvent(
        COMPONENT_AUDIO_GRAPH_INPUT_AUDIO_SINK,
        Integer.toHexString(this.hashCode()),
        EVENT_INPUT_FORMAT,
        C.TIME_UNSET,
        "AudioSinkConfig[format:%s, timeline:%s, MediaPeriodId:%s]",
        audioSinkConfig.format,
        audioSinkConfig.timeline,
        String.valueOf(audioSinkConfig.mediaPeriodId));

    currentInputFormat = audioSinkConfig.format;

    MediaPeriodId mediaPeriodId = checkNotNull(audioSinkConfig.mediaPeriodId);
    Timeline timeline = audioSinkConfig.timeline;
    currentEditedMediaItem = getEditedMediaItem(timeline, mediaPeriodId);
    this.offsetToCompositionTimeUs =
        getOffsetToCompositionTimeUs(timeline, mediaPeriodId, outputStreamOffsetUs);
    // We cannot use outputStreamOffsetUs for the first EditedMediaItem because the Timeline created
    // by ConcatenatingMediaSource2 returns the original start of the period, without taking into
    // account any clipping. For all other EditedMediaItems, outputStreamOffsetUs is aligned to the
    // clipped start.
    this.offsetToEditedMediaItemStartUs =
        timeline.getIndexOfPeriod(mediaPeriodId.periodUid) == 0
            ? -offsetToCompositionTimeUs
            : outputStreamOffsetUs;

    isConfigurationPending = true;
  }

  @Override
  public void setOutputStreamOffsetUs(long outputStreamOffsetUs) {
    this.outputStreamOffsetUs = outputStreamOffsetUs;
  }

  @Override
  public boolean isEnded() {
    // Controller can keep renderer alive if needed.
    return !isOutputInitialized()
        || (inputStreamEnded && outputGraphInput.isEnded() && controller.shouldEnd());
  }

  @Override
  public boolean handleBuffer(
      ByteBuffer buffer, long presentationTimeUs, int encodedAccessUnitCount)
      throws InitializationException {
    checkState(!inputStreamEnded);

    EditedMediaItem editedMediaItem = checkNotNull(currentEditedMediaItem);
    if (outputGraphInput == null) {

      AudioGraphInput outputGraphInput;
      try {
        outputGraphInput =
            controller.getAudioGraphInput(editedMediaItem, checkNotNull(currentInputFormat));
      } catch (ExportException e) {
        throw new InitializationException(
            "Error creating AudioGraphInput",
            AudioTrack.STATE_UNINITIALIZED,
            currentInputFormat,
            /* isRecoverable= */ false,
            e);
      }
      if (outputGraphInput == null) {
        return false;
      }
      this.outputGraphInput = outputGraphInput;
      isConfigurationPending = true;
    }

    if (isConfigurationPending) {
      // During playback, AudioGraphInput doesn't know the full media duration upfront due to
      // seeking.
      // TODO: b/406185875 - Propagate media duration after implementing handling for seeks in
      //  transitions.
      this.outputGraphInput.onMediaItemChanged(
          editedMediaItem,
          /* durationUs= */ C.TIME_UNSET,
          currentInputFormat,
          /* isLast= */ false,
          /* positionOffsetUs= */ presentationTimeUs - offsetToEditedMediaItemStartUs);
      isConfigurationPending = false;
      isFlushPending = false;
    } else if (isFlushPending) {
      this.outputGraphInput.flush(
          /* positionOffsetUs= */ presentationTimeUs - offsetToEditedMediaItemStartUs);
      isFlushPending = false;
    }

    return handleBufferInternal(buffer, presentationTimeUs, /* flags= */ 0);
  }

  @Override
  public void playToEndOfStream() {
    if (!isOutputInitialized()) {
      // AudioGraphInput has not been set up yet.
      return;
    }
    inputStreamEnded = true;
    // Play to EoS only gets called at the end of the sequence. The end of an EditedMediaItem before
    // a transition is signalled by a #handleDiscontinuity() or #flush() call.
    if (!signalledEndOfStream) {
      DebugTraceUtil.logEvent(
          COMPONENT_AUDIO_GRAPH_INPUT_AUDIO_SINK,
          Integer.toHexString(this.hashCode()),
          EVENT_INPUT_ENDED,
          inputPositionUs,
          "");
      signalledEndOfStream =
          handleBufferInternal(
              EMPTY_BUFFER, C.TIME_END_OF_SOURCE, /* flags= */ C.BUFFER_FLAG_END_OF_STREAM);
    }
  }

  @Override
  public @SinkFormatSupport int getFormatSupport(Format format) {
    if (Objects.equals(format.sampleMimeType, MimeTypes.AUDIO_RAW)
        && isEncodingLinearPcm(format.pcmEncoding)) {
      return SINK_FORMAT_SUPPORTED_DIRECTLY;
    }

    return SINK_FORMAT_UNSUPPORTED;
  }

  @Override
  public boolean supportsFormat(Format format) {
    return getFormatSupport(format) == SINK_FORMAT_SUPPORTED_DIRECTLY;
  }

  @Override
  public boolean hasPendingData() {
    // TODO: b/487191706 - Investigate whether we can just check for pending data on AudioGraphInput
    //  without stalling progress downstream. CompositionPlayer should check whether all renderers
    //  are ready before starting playback.

    // This is a best-effort approach that signals whether there are in-flight buffers between this
    // instance and the final audio sink. However, this does not guarantee that those buffers are
    // ready for immediate playback.
    return isOutputInitialized() && getCompositionPlayerPositionUs() < inputPositionUs;
  }

  @Override
  public long getCurrentPositionUs(boolean sourceEnded) {
    if (!isOutputInitialized()) {
      return CURRENT_POSITION_NOT_SET;
    }

    if (isEnded()) {
      return inputPositionUs;
    }
    return getCompositionPlayerPositionUs();
  }

  @Override
  public void play() {}

  @Override
  public void pause() {}

  @Override
  public void flush() {
    DebugTraceUtil.logEvent(
        COMPONENT_AUDIO_GRAPH_INPUT_AUDIO_SINK,
        Integer.toHexString(this.hashCode()),
        EVENT_FLUSH,
        inputPositionUs,
        "");
    inputStreamEnded = false;
    signalledEndOfStream = false;
    isFlushPending = true;
  }

  @Override
  public void reset() {
    DebugTraceUtil.logEvent(
        COMPONENT_AUDIO_GRAPH_INPUT_AUDIO_SINK,
        Integer.toHexString(this.hashCode()),
        EVENT_RESET,
        inputPositionUs,
        "");
    if (outputGraphInput != null) {
      outputGraphInput.release();
      outputGraphInput = null;
      controller.onAudioGraphInputReleased();
    }
    inputStreamEnded = false;
    signalledEndOfStream = false;
    currentInputFormat = null;
    currentEditedMediaItem = null;
    offsetToEditedMediaItemStartUs = 0;
    offsetToCompositionTimeUs = 0;
    isConfigurationPending = false;
    isFlushPending = false;
  }

  // Unsupported interface functionality.

  @Override
  public void setListener(AudioSink.Listener listener) {}

  @Override
  public void handleDiscontinuity() {
    DebugTraceUtil.logEvent(
        COMPONENT_AUDIO_GRAPH_INPUT_AUDIO_SINK,
        Integer.toHexString(this.hashCode()),
        EVENT_DISCONTINUITY,
        inputPositionUs,
        "");
  }

  @Override
  public void setAudioAttributes(AudioAttributes audioAttributes) {}

  @Nullable
  @Override
  public AudioAttributes getAudioAttributes() {
    return null;
  }

  @Override
  public long getAudioTrackBufferSizeUs() {
    return C.TIME_UNSET;
  }

  @Override
  public void setPlaybackParameters(PlaybackParameters playbackParameters) {}

  @Override
  public PlaybackParameters getPlaybackParameters() {
    return PlaybackParameters.DEFAULT;
  }

  @Override
  public void enableTunnelingV21() {}

  @Override
  public void disableTunneling() {}

  @Override
  public void setSkipSilenceEnabled(boolean skipSilenceEnabled) {}

  @Override
  public boolean getSkipSilenceEnabled() {
    return false;
  }

  @Override
  public void setAudioSessionId(int audioSessionId) {}

  @Override
  public void setAuxEffectInfo(AuxEffectInfo auxEffectInfo) {}

  @Override
  public void setVolume(float volume) {}

  // Internal methods

  @EnsuresNonNullIf(
      expression = {"outputGraphInput"},
      result = true)
  private boolean isOutputInitialized() {
    return outputGraphInput != null;
  }

  private long getCompositionPlayerPositionUs() {
    long currentPositionUs = controller.getCurrentPositionUs(/* sourceEnded= */ inputStreamEnded);
    if (currentPositionUs != CURRENT_POSITION_NOT_SET) {
      // Reset the position to the one expected by the player.
      currentPositionUs -= offsetToCompositionTimeUs;
    }
    return currentPositionUs;
  }

  private boolean handleBufferInternal(ByteBuffer buffer, long presentationTimeUs, int flags) {
    checkState(isOutputInitialized());
    checkState(!signalledEndOfStream);
    AudioGraphInput outputGraphInput = this.outputGraphInput;

    @Nullable DecoderInputBuffer outputBuffer = outputGraphInput.getInputBuffer();
    if (outputBuffer == null) {
      return false;
    }
    int bytesToWrite = buffer.remaining();
    outputBuffer.ensureSpaceForWrite(bytesToWrite);
    checkNotNull(outputBuffer.data).put(buffer).flip();
    // This is the presentation time relative to the composition.
    outputBuffer.timeUs =
        presentationTimeUs == C.TIME_END_OF_SOURCE
            ? C.TIME_END_OF_SOURCE
            : presentationTimeUs + offsetToCompositionTimeUs;
    outputBuffer.setFlags(flags);

    boolean bufferQueued = outputGraphInput.queueInputBuffer();
    if (bufferQueued) {
      checkNotNull(currentInputFormat);
      int framesToWrite =
          bytesToWrite
              / getPcmFrameSize(currentInputFormat.pcmEncoding, currentInputFormat.channelCount);
      inputPositionUs =
          presentationTimeUs
              + sampleCountToDurationUs(framesToWrite, currentInputFormat.sampleRate);
    }
    return bufferQueued;
  }
}
