/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.test.utils;

import static com.google.common.base.Preconditions.checkState;
import static com.google.common.truth.Truth.assertThat;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.DataReader;
import androidx.media3.common.Format;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.extractor.TrackOutput;
import androidx.media3.test.utils.Dumper.Dumpable;
import com.google.common.collect.ImmutableList;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

/** A fake {@link TrackOutput}. */
@UnstableApi
public final class FakeTrackOutput implements TrackOutput, Dumper.Dumpable {

  public static final Factory DEFAULT_FACTORY =
      (id, type) -> new FakeTrackOutput(type, /* deduplicateConsecutiveFormats= */ false);

  /** Factory for {@link FakeTrackOutput} instances. */
  public interface Factory {
    FakeTrackOutput create(int id, int type);
  }

  private final @C.TrackType int type;
  private final boolean deduplicateConsecutiveFormats;
  private final ArrayList<DumpableSampleInfo> sampleInfos;
  private final ArrayList<Dumpable> dumpables;
  private final ByteArrayOutputStream sampleData;

  @Nullable private byte[] cachedSampleData;
  private int formatCount;
  private boolean receivedSampleInFormat;
  private long durationUs;

  @Nullable public Format lastFormat;

  public FakeTrackOutput(@C.TrackType int type, boolean deduplicateConsecutiveFormats) {
    this.type = type;
    this.deduplicateConsecutiveFormats = deduplicateConsecutiveFormats;
    sampleInfos = new ArrayList<>();
    dumpables = new ArrayList<>();
    sampleData = new ByteArrayOutputStream();
    formatCount = 0;
    receivedSampleInFormat = true;
    durationUs = C.TIME_UNSET;
  }

  public void clear() {
    sampleInfos.clear();
    dumpables.clear();
    sampleData.reset();
    cachedSampleData = null;
    formatCount = 0;
    receivedSampleInFormat = true;
  }

  @Override
  public void durationUs(long durationUs) {
    this.durationUs = durationUs;
  }

  @Override
  public void format(Format format) {
    if (!deduplicateConsecutiveFormats) {
      checkState(
          receivedSampleInFormat,
          "deduplicateConsecutiveFormats=false so TrackOutput must receive at least one"
              + " sampleMetadata() call between format() calls.");
    } else if (!receivedSampleInFormat) {
      Dumpable dumpable = dumpables.remove(dumpables.size() - 1);
      formatCount--;
      checkState(
          dumpable instanceof DumpableFormat,
          "receivedSampleInFormat=false so expected last dumpable to be a DumpableFormat. Found:"
              + " %s",
          dumpable.getClass().getCanonicalName());
    }
    receivedSampleInFormat = false;
    addFormat(format);
  }

  @Override
  public int sampleData(
      DataReader input, int length, boolean allowEndOfInput, @SampleDataPart int sampleDataPart)
      throws IOException {
    byte[] newData = new byte[length];
    int bytesAppended = input.read(newData, 0, length);
    if (bytesAppended == C.RESULT_END_OF_INPUT) {
      if (allowEndOfInput) {
        return C.RESULT_END_OF_INPUT;
      }
      throw new EOFException();
    }
    sampleData.write(newData, 0, bytesAppended);
    cachedSampleData = null;
    return bytesAppended;
  }

  @Override
  public void sampleData(ParsableByteArray data, int length, @SampleDataPart int sampleDataPart) {
    sampleData.write(data.getData(), data.getPosition(), length);
    data.skipBytes(length);
    cachedSampleData = null;
  }

  @Override
  public void sampleMetadata(
      long timeUs,
      @C.BufferFlags int flags,
      int size,
      int offset,
      @Nullable CryptoData cryptoData) {
    receivedSampleInFormat = true;
    if (lastFormat == null) {
      throw new IllegalStateException("TrackOutput must receive format before sampleMetadata");
    }
    if (lastFormat.maxInputSize != Format.NO_VALUE && size > lastFormat.maxInputSize) {
      throw new IllegalStateException("Sample size exceeds Format.maxInputSize");
    }
    if (dumpables.isEmpty()) {
      addFormat(lastFormat);
    }
    int sampleDataLength = sampleData.size();
    addSampleInfo(
        timeUs, flags, sampleDataLength - offset - size, sampleDataLength - offset, cryptoData);
  }

  public @C.TrackType int getType() {
    return type;
  }

  public void assertSampleCount(int count) {
    assertThat(sampleInfos).hasSize(count);
  }

  public void assertSample(
      int index, byte[] data, long timeUs, int flags, @Nullable CryptoData cryptoData) {
    byte[] actualData = getSampleData(index);
    assertThat(actualData).isEqualTo(data);
    assertThat(getSampleTimeUs(index)).isEqualTo(timeUs);
    assertThat(getSampleFlags(index)).isEqualTo(flags);
    assertThat(getSampleCryptoData(index)).isEqualTo(cryptoData);
  }

  private byte[] getSampleDataArray() {
    if (cachedSampleData == null) {
      cachedSampleData = sampleData.toByteArray();
    }
    return cachedSampleData;
  }

  public byte[] getSampleData(int index) {
    return Arrays.copyOfRange(
        getSampleDataArray(), getSampleStartOffset(index), getSampleEndOffset(index));
  }

  private byte[] getSampleData(int fromIndex, int toIndex) {
    return Arrays.copyOfRange(getSampleDataArray(), fromIndex, toIndex);
  }

  public long getSampleTimeUs(int index) {
    return sampleInfos.get(index).timeUs;
  }

  public int getSampleFlags(int index) {
    return sampleInfos.get(index).flags;
  }

  @Nullable
  public CryptoData getSampleCryptoData(int index) {
    return sampleInfos.get(index).cryptoData;
  }

  public int getSampleCount() {
    return sampleInfos.size();
  }

  public ImmutableList<Long> getSampleTimesUs() {
    ImmutableList.Builder<Long> sampleTimesUs = new ImmutableList.Builder<>();
    for (DumpableSampleInfo sampleInfo : sampleInfos) {
      sampleTimesUs.add(sampleInfo.timeUs);
    }
    return sampleTimesUs.build();
  }

  public long getDurationUs() {
    return durationUs;
  }

  @Override
  public void dump(Dumper dumper) {
    dumper.add("total output bytes", sampleData.size());
    dumper.add("sample count", sampleInfos.size());
    dumper.addIfNonDefault("track duration", durationUs, C.TIME_UNSET);
    if (dumpables.isEmpty() && lastFormat != null) {
      new DumpableFormat(lastFormat, 0).dump(dumper);
    }
    for (int i = 0; i < dumpables.size(); i++) {
      dumpables.get(i).dump(dumper);
    }
  }

  private int getSampleStartOffset(int index) {
    return sampleInfos.get(index).startOffset;
  }

  private int getSampleEndOffset(int index) {
    return sampleInfos.get(index).endOffset;
  }

  private void addFormat(Format format) {
    lastFormat = format;
    dumpables.add(new DumpableFormat(format, formatCount));
    formatCount++;
  }

  private void addSampleInfo(
      long timeUs, int flags, int startOffset, int endOffset, @Nullable CryptoData cryptoData) {
    DumpableSampleInfo sampleInfo =
        new DumpableSampleInfo(timeUs, flags, startOffset, endOffset, cryptoData, getSampleCount());
    sampleInfos.add(sampleInfo);
    dumpables.add(sampleInfo);
  }

  private final class DumpableSampleInfo implements Dumper.Dumpable {
    public final long timeUs;
    public final int flags;
    public final int startOffset;
    public final int endOffset;
    @Nullable public final CryptoData cryptoData;
    public final int index;

    public DumpableSampleInfo(
        long timeUs,
        int flags,
        int startOffset,
        int endOffset,
        @Nullable CryptoData cryptoData,
        int index) {
      this.timeUs = timeUs;
      this.flags = flags;
      this.startOffset = startOffset;
      this.endOffset = endOffset;
      this.cryptoData = cryptoData;
      this.index = index;
    }

    @Override
    public void dump(Dumper dumper) {
      dumper
          .startBlock("sample " + index)
          .addTime("time", timeUs)
          .add("flags", flags)
          .add("data", getSampleData(startOffset, endOffset));
      if (cryptoData != null) {
        dumper.add("crypto mode", cryptoData.cryptoMode);
        dumper.add("encryption key", cryptoData.encryptionKey);
      }
      dumper.endBlock();
    }

    @Override
    public boolean equals(@Nullable Object o) {
      if (this == o) {
        return true;
      }
      if (o == null || getClass() != o.getClass()) {
        return false;
      }
      DumpableSampleInfo that = (DumpableSampleInfo) o;
      return timeUs == that.timeUs
          && flags == that.flags
          && startOffset == that.startOffset
          && endOffset == that.endOffset
          && index == that.index
          && Objects.equals(cryptoData, that.cryptoData);
    }

    @Override
    public int hashCode() {
      int result = (int) timeUs;
      result = 31 * result + flags;
      result = 31 * result + startOffset;
      result = 31 * result + endOffset;
      result = 31 * result + (cryptoData == null ? 0 : cryptoData.hashCode());
      result = 31 * result + index;
      return result;
    }
  }
}
